﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P02.Models
{
    public class Data1
    {

        public string Pid { get; set; }
        public string Qty { get; set; }
    }
}

