﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P02.Models;
using System.Dynamic;

namespace P02.Controllers
{
    public class LINQController : Controller
    {

        public IActionResult Demo()
        {
            Sales sales = new Sales();
            List<Order> orders =
                sales.GetOrderHistorySimplified();

            var result1 = orders;
            ViewData["result1"] = result1;

            var result2 = orders
                .Select(o => new Data1
                {
                    Pid = o.ProductId,
                    Qty = $"{o.Qty} PCS"
                }).ToList<Data1>();
            ViewData["result2"] = result2;

            var result3 =
                orders.Select(o => new
                {
                    Pid = o.ProductId,
                    Qty = $"{o.Qty} PCS"
                }).ToExpandoList();
            ViewData["result3"] = result3;

            var result4 =
                orders.Where(x => x.Price > 10)
                        .OrderByDescending(y => y.Price)
                        .Select(z => new
                        {
                            Pid = z.ProductId,
                            Cost = z.Qty * z.Price
                        }).ToExpandoList();
            ViewData["result4"] = result4;

            dynamic result5 = new
            {
                OrdersCount = orders.Count(),
                TotalCost = orders.Sum(o => o.Price * o.Qty),
                AveragePrice = orders.Average(o => o.Price),
                MinimumPrice = orders.Min(o => o.Price),
                MaximumPrice = orders.Max(o => o.Price)
            }.ToExpando();
            ViewData["result5"] = result5;


            var result6 =
            orders.OrderBy(o => o.Category)
                    .GroupBy(o => o.Category)
                    .Select(g => new
                    {
                        Cat = g.Key,
                        OrdersCount = g.Count(),
                        TotalCost = g.Sum(o => o.Price * o.Qty),
                        AveragePrice = g.Average(o => o.Price),
                        MinimumPrice = g.Min(o => o.Price),
                        MaximumPrice = g.Max(o => o.Price)
                    }
            ).ToExpandoList();
            ViewData["result6"] = result6;

            return View();
        }
    }


}