﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P02.Models;
using System.Dynamic;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace P02.Controllers
{
    public class PetHotelController : Controller
    {
        [AllowAnonymous]
        public IActionResult Index()
        {
            string userid = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<PHBooking> model = DBUtl.GetList<PHBooking>(
                                                 @"SELECT * FROM PHBooking 
                                                WHERE BookedBy = {0}",
                                                       userid);
            return View(model);
        }

        [Authorize]
        public IActionResult AddBooking()
        {
            var petTypes = DBUtl.GetList("SELECT Id, Description " +
                "FROM PHPetType ORDER BY Description");
            ViewData["PetTypes"] = new SelectList(petTypes, "Id", "Description");

            ViewData["PostTo"] = "AddBooking";
            ViewData["ButtonText"] = "Add";
            return View("Booking");
        }

        [HttpPost]
        [Authorize]
        public IActionResult AddBooking(PHBooking newBook)
        {
            string userid = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            if (ModelState.IsValid)
            {
                string sql = @"INSERT INTO PHBooking 
                                    (NRIC, OwnerName, PetName, Days, PetTypeId, 
                                     FeedFreq, FTCanned, FTDry, FtSoft, CheckInDate, BookedBy) 
                                    VALUES ('{0}', '{1}', '{2}', {3}, {4}, 
                                            {5},'{6}','{7}','{8}','{9}',{10})";

                if (DBUtl.ExecSQL(sql,
                                    newBook.NRIC, newBook.OwnerName, newBook.PetName,
                                    newBook.Days, newBook.PetTypeId, newBook.FeedFreq,
                                    newBook.FTCanned, newBook.FTDry, newBook.FTSoft,
                                    $"{newBook.CheckInDate:yyyy-MM-dd}", userid) == 1)
                    TempData["Msg"] = "New booking added.";
                else
                    TempData["Msg"] = "Failed to add new booking.";
                return RedirectToAction("Index");
            }
            else
            {
                TempData["Msg"] = "Invalid information entered!";
                return RedirectToAction("Index");
            }
        }

        [Authorize]
        public IActionResult EditBooking(int Id, bool? isDelete)
        {
            var packageTypes = DBUtl.GetList("SELECT Id, Description FROM PetTypeId ORDER BY Description");
            ViewData["PackageTypes"] = new SelectList(packageTypes, "Id", "Description");

            var slots = DBUtl.GetList("SELECT Id, Description FROM PHSlot ORDER BY Description");
            ViewData["Slots"] = new SelectList(slots, "Id", "Description");

            string userid = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<PHBooking> lstBooking = DBUtl.GetList<PHBooking>("SELECT * FROM PHBooking WHERE Id = {0} AND BookedBy={1}", Id, userid);
            PHBooking model = null;
            if (lstBooking.Count > 0)
            {
                if (isDelete.HasValue == false || isDelete == false)
                {
                    ViewData["PostTo"] = "UpdateBooking";
                    ViewData["ButtonText"] = "Update";
                }
                else
                {
                    ViewData["PostTo"] = "DeleteBooking";
                    ViewData["ButtonText"] = "Delete";
                }
                model = lstBooking[0];
                return View("Booking", model);
            }
            else
            {
                TempData["Msg"] = $"Booking {Id} not found!";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        [Authorize]
        public IActionResult EditBooking(PHBooking uBook)
        {
            // Implement your code here
            return View("NotImplemented"); // this line to be deleted
        }

        [HttpPost]
        [Authorize]
        public IActionResult DeleteBooking(PHBooking uBook)
        {
            // Implement your code here
            return View("NotImplemented"); // this line to be deleted
        }

        [Authorize]
        public IActionResult ViewBookingsByPetTypes()
        {
            string userid = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value;
            ViewData["PetTypes"] =
                        DBUtl.GetList(@"SELECT * 
                                      FROM PHPetType 
                                     ORDER BY Id");

            List<PHBooking> model = DBUtl.GetList<PHBooking>("SELECT * FROM PHBooking WHERE BookedBy = {0}", userid);
            return View(model);
        }

       
        public IActionResult SalesSummary(int ryear, int rmonth)
        {
            List<PHBooking> data = null;

            ViewData["ryear"] = ryear;
            ViewData["rmonth"] = rmonth;

            if (ryear <= 0)
            {
                data = DBUtl.GetList<PHBooking>(@"SELECT * FROM PHBooking");
                ViewData["reportheader"] = "Overall Sales Summary by Year";
                var model = data.GroupBy(b => b.CheckInDate.Year)
                    .OrderByDescending(g => g.Key)
                    .Select(g => new {
                        Group = g.Key,
                        Total = g.Sum(b => b.Cost),
                        Average = g.Average(b => b.Cost),
                        Lowest = g.Min(b => b.Cost),
                        Highest = g.Max(b => b.Cost)
                    }).ToExpandoList();

                return View(model);
            }
            else if (rmonth <= 0 || rmonth > 12)
            {
                data = DBUtl.GetList<PHBooking>(@"SELECT * FROM PHBooking
                                                            WHERE YEAR(CheckInDate) = {0}", ryear);
                ViewData["reportheader"] = $"Annual Sales Summary for {ryear} by Month";
                var model = new List<dynamic>(); // replace this line with your own code

                return View(model);
            }
            else
            {
                data = DBUtl.GetList<PHBooking>(@"SELECT * FROM PHBooking
                                                            WHERE YEAR(CheckInDate) = {0}
                                                                    AND MONTH(CheckInDate) = {1}",
                                                                    ryear, rmonth);
                ViewData["reportheader"] = $"Monthly Sales for {ryear} Month {rmonth} by Day";
                var model = new List<dynamic>(); // replace this line with your own code

                return View(model);
            }
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Reports()
        {
            var data = DBUtl.GetList<PHBooking>
            (@"SELECT bpt.*, u.Name as BookedByName
                    FROM
                    (SELECT b.*, pt.Description as PetType
                    FROM PHBooking b, PHPetType pt
                    WHERE b.PetTypeId = pt.Id) bpt, PHUser u
                    WHERE bpt.BookedBy = u.Id");

            // Report 1 - Number of Bookings by Customer
            ViewData["report1"] = new List<dynamic>(); // replace this line with your own code

            // Report 2 - Number of Bookings by Pet Type
            ViewData["report2"] = new List<dynamic>(); // replace this line with your own code

            // Report 3 - Sales by Customer
            ViewData["report3"] = new List<dynamic>(); // replace this line with your own code

            // Report 4 - Sales by Pet Type
            ViewData["report4"] = new List<dynamic>(); // replace this line with your own code

            return View();
        }

        [AllowAnonymous]
        public IActionResult AboutUs()
        {
            return View();
        }

    }
}

